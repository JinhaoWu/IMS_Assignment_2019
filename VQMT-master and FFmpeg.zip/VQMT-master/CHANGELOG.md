# CHANGELOG

## version 1.1

* Added support for large files (>2GB)
* Added support for different chroma sampling formats (YUV400, YUV420, YUV422, 
  and YUV444)

## version 1.0

* First release